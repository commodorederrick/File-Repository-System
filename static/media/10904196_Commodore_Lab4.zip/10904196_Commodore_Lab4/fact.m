function [factorial_value]= fact(number)
%NAME:COMMODORE DERRICK ID: 10904196
%This function calculates the exact factorial value of a number.
factorial_value=1;
 if(number==0)
     factorial_value=1;
 else
     for i=1:1:number
         factorial_value=(factorial_value)*i;
     end
 end
end

