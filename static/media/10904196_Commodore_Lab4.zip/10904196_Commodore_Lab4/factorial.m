%NAME: COMMODORE DERRICK ID: 10904196
number=input('Enter a non-negative whole number:  ');
factorial_value=fact(number);
if number<0
    disp('Factorial is defined for non-negative integers. Try again')
else  
fprintf('The factorial value of the entered number is: %f\n',factorial_value)
end


